﻿namespace Notex.UserAccess
{
    public class Class1
    {

    }
}