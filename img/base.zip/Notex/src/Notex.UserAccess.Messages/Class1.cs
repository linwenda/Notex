﻿namespace Notex.UserAccess.Messages
{
    public class Class1
    {

    }
}