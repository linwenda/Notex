﻿namespace Notex.Creation.Messages
{
    public class Class1
    {

    }
}