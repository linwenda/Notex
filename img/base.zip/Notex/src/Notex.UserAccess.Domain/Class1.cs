﻿namespace Notex.UserAccess.Domain
{
    public class Class1
    {

    }
}