namespace Notex.Infrastructure.Abstraction.EventSourcing;

public abstract class BusinessException : Exception
{
    protected BusinessException()
    {
    }

    protected BusinessException(string message) : base(message)
    {
    }
}