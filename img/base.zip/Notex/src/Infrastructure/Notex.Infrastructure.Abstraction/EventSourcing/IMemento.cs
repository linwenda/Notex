namespace Notex.Infrastructure.Abstraction.EventSourcing;

public interface IMemento
{
    Guid AggregateId { get; }
    int AggregateVersion { get; }
}