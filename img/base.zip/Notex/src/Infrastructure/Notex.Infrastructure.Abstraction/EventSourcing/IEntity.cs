namespace Notex.Infrastructure.Abstraction.EventSourcing;

public interface IEntity
{
}