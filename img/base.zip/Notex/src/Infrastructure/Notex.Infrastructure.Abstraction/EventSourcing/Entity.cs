namespace Notex.Infrastructure.Abstraction.EventSourcing;

public abstract class Entity : IEntity
{
}