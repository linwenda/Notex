using Notex.Infrastructure.Abstraction.Messaging;

namespace Notex.Infrastructure.Abstraction.EventSourcing;

public interface IVersionedEvent : IEvent
{
    public Guid AggregateId { get; }
    public int AggregateVersion { get; }
}