namespace Notex.Infrastructure.Abstraction.EventSourcing;

public interface IAggregateRoot
{
    Guid Id { get; }
}