namespace Notex.Infrastructure.Abstraction.EventSourcing;

public interface IMementoOriginator
{
    IMemento GetMemento();
    void SetMemento(IMemento memento);
}