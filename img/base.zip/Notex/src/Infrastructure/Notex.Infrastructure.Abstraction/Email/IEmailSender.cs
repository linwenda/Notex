namespace Notex.Infrastructure.Abstraction.Email;

public interface IEmailSender
{
    Task SendAsync(string to, string subject, string content);
}