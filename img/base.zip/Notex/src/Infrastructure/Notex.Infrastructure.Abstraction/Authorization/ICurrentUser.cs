namespace Notex.Infrastructure.Abstraction.Authorization;

public interface ICurrentUser
{
    Guid Id { get; }
}