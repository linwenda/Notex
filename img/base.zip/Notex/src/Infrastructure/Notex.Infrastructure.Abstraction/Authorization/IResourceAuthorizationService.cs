using Microsoft.AspNetCore.Authorization;

namespace Notex.Infrastructure.Abstraction.Authorization;

public interface IResourceAuthorizationService
{
    Task CheckAsync(object resource, IAuthorizationRequirement requirement);
}