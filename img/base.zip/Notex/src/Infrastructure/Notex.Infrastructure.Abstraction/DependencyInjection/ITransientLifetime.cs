﻿namespace Notex.Infrastructure.Abstraction.DependencyInjection;

public interface ITransientLifetime
{
}