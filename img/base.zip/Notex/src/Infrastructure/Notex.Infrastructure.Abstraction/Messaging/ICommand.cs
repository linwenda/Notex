﻿using MediatR;

namespace Notex.Infrastructure.Abstraction.Messaging
{
    public interface ICommand<out TResponse> : IRequest<TResponse>
    {
    }

    public interface ICommand : ICommand<Unit>
    {
    }
}
