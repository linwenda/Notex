﻿using MediatR;

namespace Notex.Infrastructure.Abstraction.Messaging
{
    public interface IEvent : INotification
    {
        DateTimeOffset OccurrenceTime { get; }
    }
}
