using MediatR;

namespace Notex.Infrastructure.Abstraction.Messaging;

public interface IEventHandler<in TEvent> : INotificationHandler<TEvent> where TEvent : IEvent
{
}