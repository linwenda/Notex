﻿namespace Notex.Infrastructure.Abstraction.Messaging
{
    public interface IInternalCommand : ICommand
    {
    }
}
