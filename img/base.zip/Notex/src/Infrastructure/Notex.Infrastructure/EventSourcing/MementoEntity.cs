using System.Text.Json;

namespace Notex.Infrastructure.EventSourcing;

public class MementoEntity
{
    public Guid AggregateId { get; set; }
    public int AggregateVersion { get; set; }
    public JsonDocument Payload { get; set; }
    public string Type { get; set; }
}