using Microsoft.EntityFrameworkCore;

namespace Notex.Infrastructure.EventSourcing;

public class EventStoreDbContext : DbContext
{
    
}