﻿namespace Notex.Creation
{
    public class Class1
    {

    }
}