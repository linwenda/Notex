﻿namespace Notex.Creation.Domain
{
    public class Class1
    {

    }
}